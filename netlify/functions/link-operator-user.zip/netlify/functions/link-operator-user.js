// netlify/functions/link-operator-user.js
//
// Called by the operator client after first login when the user_id
// in operator_members has not yet been set, OR when no operator_members
// row exists at all for the authenticated user.
//
// POST  (Authorization: Bearer <supabase-access-token>)
//
// Flow:
//   1. Verify token → get auth user (email, id)
//   2. Look up operator by email → create one if missing
//   3. Look up operator_members for this operator → create row if missing
//   4. Set user_id on the operator_members row
//
// This mirrors the provisioning logic in admin-approve-onboarding.js
// and provision-tenant.js so that authenticated users without
// memberships are bootstrapped automatically.

const { getAdminClient, respond } = require('./utils/auth');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return respond(200, {});
  if (event.httpMethod !== 'POST')    return respond(405, { error: 'Method not allowed' });

  const authHeader =
    event.headers['authorization'] || event.headers['Authorization'] || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : null;
  if (!token) return respond(401, { error: 'Missing authorization token' });

  const supabase = getAdminClient();

  // Verify the token
  const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
  if (authErr || !user) {
    return respond(401, { error: 'Invalid or expired token' });
  }

  const email = (user.email || '').toLowerCase();

  // ── Step 1: Find or create operator row ────────────────────────────────────
  let { data: operator, error: opErr } = await supabase
    .from('operators')
    .select('id, email, tenant_id')
    .eq('email', email)
    .maybeSingle();

  if (opErr) {
    console.error('[link-operator-user] operator lookup failed:', opErr.message);
    return respond(500, { error: 'Operator lookup failed' });
  }

  // If no operator row exists, try to resolve a tenant and create the operator
  if (!operator) {
    const tenantId = await resolveTenantId(supabase, email, user);

    if (!tenantId) {
      console.warn(`[link-operator-user] No operator and no tenant found for ${email}`);
      return respond(404, { error: 'No operator found for this email' });
    }

    const displayName =
      user.user_metadata?.full_name ||
      user.user_metadata?.name ||
      email.split('@')[0];

    const { data: newOp, error: insertOpErr } = await supabase
      .from('operators')
      .upsert([{
        email,
        name     : displayName,
        role     : 'tenant_owner',
        tenant_id: tenantId,
      }], { onConflict: 'email' })
      .select('id, email, tenant_id')
      .single();

    if (insertOpErr || !newOp) {
      console.error('[link-operator-user] operator creation failed:', insertOpErr?.message);
      return respond(500, { error: 'Could not create operator' });
    }

    operator = newOp;
    console.log(`[link-operator-user] Created operator ${operator.id} for ${email}`);
  }

  // ── Step 2: Ensure operator_members row exists ─────────────────────────────
  const { data: existingMember } = await supabase
    .from('operator_members')
    .select('operator_id, tenant_id, user_id')
    .eq('operator_id', operator.id)
    .limit(1)
    .maybeSingle();

  if (existingMember) {
    // Row exists — just link user_id if not already set
    if (!existingMember.user_id || existingMember.user_id !== user.id) {
      const { error: updateErr } = await supabase
        .from('operator_members')
        .update({ user_id: user.id })
        .eq('operator_id', operator.id);

      if (updateErr) {
        console.error('[link-operator-user] user_id update failed:', updateErr.message);
        return respond(500, { error: 'Could not link user to operator' });
      }
    }

    console.log(`[link-operator-user] Linked auth user ${user.id} → operator ${operator.id}`);
    return respond(200, { linked: true, operator_id: operator.id });
  }

  // No operator_members row — bootstrap one
  const tenantId = operator.tenant_id || await resolveTenantId(supabase, email, user);

  if (!tenantId) {
    console.warn(`[link-operator-user] Cannot bootstrap membership: no tenant for ${email}`);
    return respond(404, { error: 'No tenant found to bootstrap membership' });
  }

  // Ensure operator.tenant_id is set
  if (!operator.tenant_id) {
    await supabase
      .from('operators')
      .update({ tenant_id: tenantId })
      .eq('id', operator.id);
  }

  const { error: memberErr } = await supabase
    .from('operator_members')
    .upsert([{
      operator_id: operator.id,
      tenant_id  : tenantId,
      role       : 'owner',
      user_id    : user.id,
    }], { onConflict: 'operator_id,tenant_id' });

  if (memberErr) {
    console.error('[link-operator-user] membership bootstrap failed:', memberErr.message);
    return respond(500, { error: 'Could not bootstrap operator membership' });
  }

  console.log(`[link-operator-user] Bootstrapped membership: auth user ${user.id} → operator ${operator.id} → tenant ${tenantId}`);
  return respond(200, { linked: true, operator_id: operator.id, bootstrapped: true });
};

// ── Helper: resolve a tenant_id for a given email ────────────────────────────
// Checks (in order):
//   1. tenants.owner_email matches
//   2. A provisioned onboarding request for this email has a linked tenant
async function resolveTenantId(supabase, email, user) {
  // Try tenants table by owner_email
  const { data: tenant } = await supabase
    .from('tenants')
    .select('id')
    .eq('owner_email', email)
    .eq('active', true)
    .limit(1)
    .maybeSingle();

  if (tenant?.id) return tenant.id;

  // Try onboarding requests → linked tenant
  const { data: onboarding } = await supabase
    .from('tenant_onboarding_requests')
    .select('id, status')
    .eq('owner_email', email)
    .eq('status', 'provisioned')
    .limit(1)
    .maybeSingle();

  if (onboarding?.id) {
    const { data: linkedTenant } = await supabase
      .from('tenants')
      .select('id')
      .eq('onboarding_request_id', onboarding.id)
      .limit(1)
      .maybeSingle();

    if (linkedTenant?.id) return linkedTenant.id;
  }

  return null;
}
